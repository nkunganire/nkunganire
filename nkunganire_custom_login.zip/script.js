
document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault();
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const twoFactor = document.getElementById("twoFactor").value;

    if (email && password && twoFactor) {
        alert("Login successful! Welcome to Nkunganire.");
    } else {
        alert("Please fill in all fields before submitting.");
    }
});
